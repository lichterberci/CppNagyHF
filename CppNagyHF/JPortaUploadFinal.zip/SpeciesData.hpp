#pragma once

namespace model {

	struct SpeciesData {
		int age;
		double startFitness;
		double lastFitness;
	};

}
